<?php
/**
 * Services Sections 1
 */
return array(
	'title'      => esc_html__( 'Services Sections 1 ', 'elvotix-fse' ),
	'categories' => array( 'elvotix-fse', 'Services Sections 1' ),
	'content'    => '<!-- wp:group {"className":"fse-sections-01","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"#01ab55"}},"layout":{"type":"default"}} -->
<div class="wp-block-group fse-sections-01 has-background" style="background-color:#01ab55;padding-top:0;padding-right:var(--wp--preset--spacing--50);padding-bottom:0;padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"0","left":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0"><!-- wp:column {"width":"34%","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|70","right":"var:preset|spacing|70"}}}} -->
<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70);flex-basis:34%"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h5 class="wp-block-heading has-foreground-color has-text-color has-link-color has-poppins-font-family" style="margin-top:0;margin-bottom:0;font-size:20px;font-style:normal;font-weight:500">Main issues</h5>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"42px","fontStyle":"normal","fontWeight":"600","lineHeight":"1.1"},"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h3 class="wp-block-heading has-foreground-color has-text-color has-link-color has-poppins-font-family" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30);font-size:42px;font-style:normal;font-weight:600;line-height:1.1">Politician<br>Priorities</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->
<p class="has-foreground-color has-text-color has-link-color">Sed ut perspiciatis unde omnis<br>iste natus error sit vouptatema<br>ccusantium dolore.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"22%","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}},"color":{"background":"#02934a"}}} -->
<div class="wp-block-column has-background" style="background-color:#02934a;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--60);flex-basis:22%"><!-- wp:image {"id":3327,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/elv-services-01.png" alt="" class="wp-image-3327"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"22px","fontStyle":"normal","fontWeight":"300"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h5 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:22px;font-style:normal;font-weight:300">Balancing The<br>Budget</h5>
<!-- /wp:heading -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"foreground","textColor":"body-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"border":{"radius":"30px"},"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-body-text-color has-foreground-background-color has-text-color has-background has-link-color wp-element-button" style="border-radius:30px;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--50)">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"22%","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}},"color":{"background":"#008241"}}} -->
<div class="wp-block-column has-background" style="background-color:#008241;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--60);flex-basis:22%"><!-- wp:image {"id":3334,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/elv-services-02.png" alt="" class="wp-image-3334"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"22px","fontStyle":"normal","fontWeight":"300"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h5 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:22px;font-style:normal;font-weight:300">Growing Our<br>Economy</h5>
<!-- /wp:heading -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"foreground","textColor":"body-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"border":{"radius":"30px"},"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-body-text-color has-foreground-background-color has-text-color has-background has-link-color wp-element-button" style="border-radius:30px;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--50)">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"22%","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}},"color":{"background":"#00743a"}}} -->
<div class="wp-block-column has-background" style="background-color:#00743a;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--60);flex-basis:22%"><!-- wp:image {"id":3335,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/elv-services-03.png" alt="" class="wp-image-3335"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"22px","fontStyle":"normal","fontWeight":"300"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h5 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:22px;font-style:normal;font-weight:300">Creating<br>Jobs</h5>
<!-- /wp:heading -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"foreground","textColor":"body-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"border":{"radius":"30px"},"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-body-text-color has-foreground-background-color has-text-color has-background has-link-color wp-element-button" style="border-radius:30px;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--50)">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);