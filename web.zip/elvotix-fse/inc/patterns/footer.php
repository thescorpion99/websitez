<?php
/**
 * Footer
 */
return array(
	'title'      => esc_html__( 'Footer', 'elvotix-fse' ),
	'categories' => array( 'elvotix-fse', 'footer' ),
	'content'    => '<!-- wp:group {"className":"site-footer","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}}},"backgroundColor":"foreground","textColor":"body-text","layout":{"type":"default"}} -->
<div class="wp-block-group site-footer has-body-text-color has-foreground-background-color has-text-color has-background has-link-color" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|50","left":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"body-text","fontFamily":"poppins"} -->
<h3 class="wp-block-heading has-body-text-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">About Elvotix</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|50"}}},"textColor":"body-text"} -->
<p class="has-body-text-color has-text-color has-link-color" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--50);font-size:16px">Perspi ciatis und omnis iste natus volupte atemi omnis istei pulvinar ultricies dolory amet tempus.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"border":{"radius":"10px","width":"2px"},"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"position":{"type":""}},"borderColor":"primary","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group has-border-color has-primary-border-color" style="border-width:2px;border-radius:10px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"id":3384,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/footer-phone-icon-1.png" alt="" class="wp-image-3384"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"600"}}} -->
<p style="font-size:20px;font-style:normal;font-weight:600">+12345678910</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"20%"} -->
<div class="wp-block-column" style="flex-basis:20%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"heading","fontFamily":"poppins"} -->
<h3 class="wp-block-heading has-heading-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">Overview</h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"Footer-QuickLinks","style":{"spacing":{"padding":{"right":"var:preset|spacing|40","left":"var:preset|spacing|40","top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}}},"textColor":"heading"} -->
<ul style="padding-top:0;padding-right:var(--wp--preset--spacing--40);padding-bottom:0;padding-left:var(--wp--preset--spacing--40)" class="wp-block-list Footer-QuickLinks has-heading-color has-text-color has-link-color"><!-- wp:list-item -->
<li><a href="#">Donation</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Join Page</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Volunteering</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Working Process</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Mission &amp; Vision</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Reservation</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"20%"} -->
<div class="wp-block-column" style="flex-basis:20%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"heading","fontFamily":"poppins"} -->
<h3 class="wp-block-heading has-heading-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">Quick Links</h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"Footer-QuickLinks","style":{"spacing":{"padding":{"right":"var:preset|spacing|40","left":"var:preset|spacing|40","top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}}},"textColor":"heading"} -->
<ul style="padding-top:0;padding-right:var(--wp--preset--spacing--40);padding-bottom:0;padding-left:var(--wp--preset--spacing--40)" class="wp-block-list Footer-QuickLinks has-heading-color has-text-color has-link-color"><!-- wp:list-item -->
<li><a href="#">Home</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">About Us</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Blog</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Services</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Projects</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Contact US</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"heading","fontFamily":"poppins"} -->
<h3 class="wp-block-heading has-heading-color has-text-color has-link-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">Latest Posts</h3>
<!-- /wp:heading -->

<!-- wp:latest-posts {"postsToShow":3,"displayPostDate":true,"className":"footer-latest-news","style":{"color":{"text":"#909093"},"elements":{"link":{"color":{"text":"#909093"}}}}} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"backgroundColor":"primary","textColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group has-foreground-color has-primary-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group" style="padding-top:0;padding-bottom:0"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->
<p class="has-foreground-color has-text-color has-link-color">Elvotix FSE</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->
<p class="has-text-align-left has-foreground-color has-text-color has-link-color">Design by Grace Themes </p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);