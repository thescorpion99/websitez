=== Elvotix FSE ===
Contributors: gracethemes
Tags:blog, news, one-column, two-columns, right-sidebar, block-styles, custom-colors, editor-style, custom-background, custom-menu, featured-images, template-editing, full-site-editing, block-patterns,  threaded-comments, wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.6
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Elvotix FSE is a free political candidate WordPress theme for activist, campaign, charity, community, democrat, election, foundation, party, politician, republican and voters. It is a meticulously crafted WordPress theme that caters to various political websites. You can readily use it for free political membership sites, nonprofit organizations, political campaigns, etc. You can seamlessly customize this theme according to your preferences and requirements. Every element of this option including the header and footer is completely personalizable. So, you can easily add personal touches to your website using preferable logos, designs, and color schemes. This theme comes with an incredibly responsive design that runs perfectly on all devices despite the resolution. Elvotix FSE comes with a mobile-friendly design. So, if you wish to, you can easily operate it on your mobile phone. Elvotix FSE offers the best speed optimization feature by efficiently optimizing images, videos, and other content. Elvotix FSE offers extensive SEO features like meta tags and descriptions, customized titles, XML sitemap generation, Google Analytics integration, etc to make your website receive an improved website ranking. Besides, important SEO plugins like Yoast SEO and RankMath are compatible with this option to enhance the conversion rates of your website.

== Theme License & Copyright == 

* Elvotix FSE WordPress Theme, Copyright 2025 Grace Themes 
* Elvotix FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

= 1.1 =
* Skip to content on 404 error page and search result page as per reviewwer Requirement.


== Resources ==

Theme is Built using the following resource bundles.

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/868229 ( Header Banner image)


= Icon Images =

  * Grace Themes Self Designed icons images:	
	assets/images/elv-email.png
	assets/images/elv-phone.png
	assets/images/elv-services-01.png
	assets/images/elv-services-02.png
	assets/images/elv-services-03.png
	assets/images/footer-phone-icon.png
	assets/images/mision-vision-icon01.png
	assets/images/mision-vision-icon02.png
	assets/images/mision-vision-icon03.png	

= Google Fonts =

     * Poppins		
        Source: https://fonts.google.com/specimen/Poppins
        License: SIL Open Font License, 1.1,  https://opensource.org/license/OFL-1.1
       

    
For any help you can mail us at support@gracethemes.com